-- FS-Version: 	FS19
-- Title:   	FillTypeMover 
-- author:  	Farmer_Schubi
-- date:    	26.04.2019
-- Version: 	1.0.0.1

-- Copyright (©) by Farmer_Schubi

-- 28.04.2019 erweitert um mehrere FillTypes pro Rohstoff und einen zweiten Rohstoff

FillTypeMover = {};

local modDesc = loadXMLFile("modDesc", g_currentModDirectory .. "modDesc.xml");
local updateMs = 60000;
FillTypeMover.version = getXMLString(modDesc, "modDesc.version");
FillTypeMover.modDirectory = g_currentModDirectory;
local i = 0;
local modDescKey = string.format("modDesc.storeItems(%d).storeItem", i)
if hasXMLProperty(modDesc, modDescKey) then
	local modxmlname = Utils.getNoNil(getXMLString(modDesc, modDescKey .. "#xmlFilename"), "Unknown");
--	print("modDescKey: " .. modDescKey .. "modxmlname:  " .. modxmlname);
	
	local modxml = loadXMLFile("modxml", g_currentModDirectory .. modxmlname);
	if hasXMLProperty(modxml, "placeable.storeData.name") then
		FillTypeMover.storename = getXMLString(modxml, "placeable.storeData.name");
	else
		FillTypeMover.storename = "";
	end;
--	print("storename: " .. FillTypeMover.storename);
	
	if hasXMLProperty(modxml, "placeable.litersPerMin") then
		FillTypeMover.litersPerMin = getXMLInt(modxml, "placeable.litersPerMin");
	else
		FillTypeMover.litersPerMin = 100;
	end;
--	print("litersPerMin: " .. FillTypeMover.litersPerMin);
	
	local capacityPerFillTypeKey = string.format("placeable.storages(%d).storage", i)	
	FillTypeMover.capacityPerFillType = Utils.getNoNil(getXMLInt(modxml, capacityPerFillTypeKey .. "#capacityPerFillType"), "Unknown");
	if FillTypeMover.capacityPerFillType == "Unknown" then
		FillTypeMover.capacityPerFillType = 500000;
	end;
--	print("capacityPerFillType: " .. FillTypeMover.capacityPerFillType);

	if hasXMLProperty(modxml, "placeable.filltypename_in1") then
		l_in = utf8ToUpper(getXMLString(modxml, "placeable.filltypename_in1"));
	end;
	if l_in ~= nil then
--		print("filltypename_in1: " .. l_in);	
		lt_in1 = {}
		for substring in l_in:gmatch("%S+") do
		   table.insert(lt_in1, substring)
		end
	end;

	if hasXMLProperty(modxml, "placeable.filltypename_in2") then
		l_in = utf8ToUpper(getXMLString(modxml, "placeable.filltypename_in2"));
	else
		l_in = "";
	end;	
	if l_in ~= nil then	
--		print("filltypename_in2: " .. l_in);	
		lt_in2 = {}
		for substring in l_in:gmatch("%S+") do
		   table.insert(lt_in2, substring)
		end
	end;
	
	if hasXMLProperty(modxml, "placeable.filltypename_in3") then
		l_in = utf8ToUpper(getXMLString(modxml, "placeable.filltypename_in3"));
	else
		l_in = "";
	end;	
	if l_in ~= nil then	
--		print("filltypename_in3: " .. l_in);	
		lt_in3 = {}
		for substring in l_in:gmatch("%S+") do
		   table.insert(lt_in3, substring)
		end
	end;
	
	if hasXMLProperty(modxml, "placeable.percentage_in1") then
		FillTypeMover.percentage_in1 = Utils.getNoNil(getXMLInt(modxml, "placeable.percentage_in1"), 100);
	else
		FillTypeMover.percentage_in1 = 100;
	end;	
--	print("percentage_in1: " .. FillTypeMover.percentage_in1);	

	if hasXMLProperty(modxml, "placeable.percentage_in2") then
		FillTypeMover.percentage_in2 = Utils.getNoNil(getXMLInt(modxml, "placeable.percentage_in2"), 0);
	else
		FillTypeMover.percentage_in2 = 100 - FillTypeMover.percentage_in1;
	end;	
--	print("percentage_in2: " .. FillTypeMover.percentage_in2);	

	if hasXMLProperty(modxml, "placeable.percentage_in3") then
		FillTypeMover.percentage_in3 = Utils.getNoNil(getXMLInt(modxml, "placeable.percentage_in3"), 0);
	else
		FillTypeMover.percentage_in3 = 100 - FillTypeMover.percentage_in1 - FillTypeMover.percentage_in2;
	end;	
	if (FillTypeMover.percentage_in1 + FillTypeMover.percentage_in2 + FillTypeMover.percentage_in3) > 100 then
	  FillTypeMover.percentage_in3 = 100 - FillTypeMover.percentage_in1 - FillTypeMover.percentage_in2;
	end;
--	print("percentage_in3: " .. FillTypeMover.percentage_in3);	

	if hasXMLProperty(modxml, "placeable.filltypename_out") then
		FillTypeMover.filltypename_out = utf8ToUpper(getXMLString(modxml, "placeable.filltypename_out"));
	else
		FillTypeMover.filltypename_out = utf8ToUpper("drygrass_windrow");
	end;	
--	print("filltypename_out: " .. FillTypeMover.filltypename_out);	
end

addModEventListener(FillTypeMover);

function FillTypeMover:loadMap()

print("############################################################");
print("--- FillTypeMover " .. self.version);
print("############################################################");
end

--function FillTypeMover:keyEvent(unicode, sym, modifier, isDown)

--end;

--function FillTypeMover:mouseEvent(posX, posY, isDown, isUp, button)
--end;


function FillTypeMover:deleteMap()
end;

function FillTypeMover:update(dt)
	local plus = 0;
	updateMs = updateMs + (dt * g_currentMission.loadingScreen.missionInfo.timeScale);
	if updateMs >= 60000   then
		updateMs = updateMs - 60000;
--		print("--- FillTypeMover dt:" .. dt .. updateMs);
		for a=1, #g_currentMission.placeables do
			if g_currentMission.placeables[a] ~= nil then
				local object = g_currentMission.placeables[a];
				if object ~= nil and object.nodeId ~= nil then
					if object.storages ~= nil and type(object.storages) == "table" and object.loadingStation ~= nil and object.loadingStation.stationName ~= nil  and object.loadingStation.stationName == FillTypeMover.storename then
--						print("nodeId "  .. object.nodeId .. "FarmId " .. object.storages[1].ownerFarmId ..  "stationName " .. Utils.getNoNil(object.loadingStation.stationName, "Unknown"));
--						DebugUtil.printTableRecursively(object.storages[1].fillTypes,".",0,1);
                        found1 = false;
						for i,filltypename_in,isAccepted in pairs(lt_in1) do
							FillTypeMover.filltypename_in = filltypename_in;
--							print("filltypename_in: " .. FillTypeMover.filltypename_in);
							for fillType_in,isAccepted in pairs(object.storages[1].fillTypes) do
								local filltypename_in = g_fillTypeManager.indexToName[fillType_in];
								if filltypename_in == FillTypeMover.filltypename_in then
									if object.storages[1].fillLevels[fillType_in] > 0 then
										for fillType_out,isAccepted in pairs(object.storages[1].fillTypes) do
											local filltypename_out = g_fillTypeManager.indexToName[fillType_out];
											if filltypename_out == FillTypeMover.filltypename_out then
												if object.storages[1].fillLevels[fillType_in] > (FillTypeMover.litersPerMin * FillTypeMover.percentage_in1 / 100) then
													plus1 = (FillTypeMover.litersPerMin * FillTypeMover.percentage_in1 / 100);
													plus1_low = false;
												else
													plus1 =  object.storages[1].fillLevels[fillType_in];
													plus1_low = true;
												end;
	--											print("plus1: " .. plus1);
												out = object.storages[1].fillLevels[fillType_out] + FillTypeMover.litersPerMin;
												if out <= FillTypeMover.capacityPerFillType then
													fillType_in_found1  = fillType_in;
													fillType_out_found = fillType_out;
													found1 = true;
												end;
											end;
										end;	
									end;
								end;
							end;
							if found1 then 
								break;
							end;
						end;
						
                        found2 = false;
						in2 = false;
						for i,filltypename_in,isAccepted in pairs(lt_in2) do
							in2 = true;
							FillTypeMover.filltypename_in = filltypename_in;
--							print("filltypename_in: " .. FillTypeMover.filltypename_in);
							for fillType_in,isAccepted in pairs(object.storages[1].fillTypes) do
								local filltypename_in = g_fillTypeManager.indexToName[fillType_in];
								if filltypename_in == FillTypeMover.filltypename_in then
									if object.storages[1].fillLevels[fillType_in] > 0 then
										for fillType_out,isAccepted in pairs(object.storages[1].fillTypes) do
											local filltypename_out = g_fillTypeManager.indexToName[fillType_out];
											if filltypename_out == FillTypeMover.filltypename_out then
												if object.storages[1].fillLevels[fillType_in] > (FillTypeMover.litersPerMin * FillTypeMover.percentage_in2 / 100) then
													plus2 = (FillTypeMover.litersPerMin * FillTypeMover.percentage_in2 / 100);
													plus2_low = false;
												else
													plus2 =  object.storages[1].fillLevels[fillType_in];
													plus2_low = true;
												end;
	--											print("plus2: " .. plus2);
												out = object.storages[1].fillLevels[fillType_out] + FillTypeMover.litersPerMin;
												if out <= FillTypeMover.capacityPerFillType then
													fillType_in_found2  = fillType_in;
													fillType_out_found = fillType_out;
													found2 = true;
												end;
											end;
										end;	
									end;
								end;
							end;
							if found2 then 
								break;
							end;
						end;

                        found3 = false;
						in3 = false;
						for i,filltypename_in,isAccepted in pairs(lt_in3) do
							in3 = true;
							FillTypeMover.filltypename_in = filltypename_in;
--							print("filltypename_in: " .. FillTypeMover.filltypename_in);
							for fillType_in,isAccepted in pairs(object.storages[1].fillTypes) do
								local filltypename_in = g_fillTypeManager.indexToName[fillType_in];
								if filltypename_in == FillTypeMover.filltypename_in then
									if object.storages[1].fillLevels[fillType_in] > 0 then
										for fillType_out,isAccepted in pairs(object.storages[1].fillTypes) do
											local filltypename_out = g_fillTypeManager.indexToName[fillType_out];
											if filltypename_out == FillTypeMover.filltypename_out then
												if object.storages[1].fillLevels[fillType_in] > (FillTypeMover.litersPerMin * FillTypeMover.percentage_in3 / 100) then
													plus3 = (FillTypeMover.litersPerMin * FillTypeMover.percentage_in3 / 100);
													plus3_low = false;
												else
													plus3 =  object.storages[1].fillLevels[fillType_in];
													plus3_low = true;
												end;
	--											print("plus3: " .. plus3);
												out = object.storages[1].fillLevels[fillType_out] + FillTypeMover.litersPerMin;
												if out <= FillTypeMover.capacityPerFillType then
													fillType_in_found3  = fillType_in;
													fillType_out_found = fillType_out;
													found3 = true;
												end;
											end;
										end;	
									end;
								end;
							end;
							if found3 then 
								break;
							end;
						end;


--						DebugUtil.printTableRecursively(lt_in1,".",0,1);						
--						DebugUtil.printTableRecursively(lt_in2,".",0,1);						
						if found1 == true and found2 == false and in2 == false and found3 == false and in3 == false then
							filltypename_in1  = g_fillTypeManager.indexToName[fillType_in_found1];
							filltypename_out  = g_fillTypeManager.indexToName[fillType_out_found];
						
							object.storages[1].fillLevels[fillType_out_found] = object.storages[1].fillLevels[fillType_out_found] + plus1;
							object.storages[1].fillLevels[fillType_in_found1] = object.storages[1].fillLevels[fillType_in_found1] - plus1;
							print("Skript 3: " .. FillTypeMover.storename .. " fillType_in1 " .. filltypename_in1 .. " fillLevels " .. math.floor(object.storages[1].fillLevels[fillType_in_found1]) .. "  fillType_out " .. filltypename_out .. " " .. math.floor(object.storages[1].fillLevels[fillType_out_found]));				
						end;

						if found1 == true and found2 == true and found3 == false and in3 == false  then
							filltypename_in1  = g_fillTypeManager.indexToName[fillType_in_found1];
							filltypename_in2  = g_fillTypeManager.indexToName[fillType_in_found2];
							filltypename_out  = g_fillTypeManager.indexToName[fillType_out_found];
							if plus1_low then
							  plus2 = plus2 * (plus1 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in1 / 100)) / 100;
							end;
							if plus2_low then
							  plus1 = plus1 * (plus2 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in2 / 100)) / 100;
							end;
							
							object.storages[1].fillLevels[fillType_out_found] = object.storages[1].fillLevels[fillType_out_found] + plus1 + plus2;
							object.storages[1].fillLevels[fillType_in_found1] = object.storages[1].fillLevels[fillType_in_found1] - plus1;
							object.storages[1].fillLevels[fillType_in_found2] = object.storages[1].fillLevels[fillType_in_found2] - plus2;
							print("Skript 3: " .. FillTypeMover.storename .. " fillType_in1 " .. filltypename_in1 .. " fillLevels " .. math.floor(object.storages[1].fillLevels[fillType_in_found1]) .. " fillType_in2 " .. filltypename_in2 .. " " .. math.floor(object.storages[1].fillLevels[fillType_in_found2]) .. "  fillType_out " .. filltypename_out .. " " .. math.floor(object.storages[1].fillLevels[fillType_out_found]));				
						end;						
						
						if found1 and found2 and found3 then
							filltypename_in1  = g_fillTypeManager.indexToName[fillType_in_found1];
							filltypename_in2  = g_fillTypeManager.indexToName[fillType_in_found2];
							filltypename_in3  = g_fillTypeManager.indexToName[fillType_in_found3];
							filltypename_out  = g_fillTypeManager.indexToName[fillType_out_found];
							if plus1_low then
							  plus2 = plus2 * (plus1 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in1 / 100)) / 100;
							  plus3 = plus3 * (plus1 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in1 / 100)) / 100;							  
							end;
							if plus2_low then
							  plus1 = plus1 * (plus2 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in2 / 100)) / 100;
							  plus3 = plus3 * (plus2 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in2 / 100)) / 100;
							end;
							if plus3_low then
							  plus1 = plus1 * (plus3 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in3 / 100)) / 100;
							  plus2 = plus2 * (plus3 * 100 / (FillTypeMover.litersPerMin * FillTypeMover.percentage_in3 / 100)) / 100;
							end;					
							object.storages[1].fillLevels[fillType_out_found] = object.storages[1].fillLevels[fillType_out_found] + plus1 + plus2 + plus3;
							object.storages[1].fillLevels[fillType_in_found1] = object.storages[1].fillLevels[fillType_in_found1] - plus1;
							object.storages[1].fillLevels[fillType_in_found2] = object.storages[1].fillLevels[fillType_in_found2] - plus2;
							object.storages[1].fillLevels[fillType_in_found3] = object.storages[1].fillLevels[fillType_in_found3] - plus3;
							print("Skript 3: " .. FillTypeMover.storename .. " fillType_in1 " .. filltypename_in1 .. " fillLevels " .. math.floor(object.storages[1].fillLevels[fillType_in_found1]) .. " fillType_in2 " .. filltypename_in2 .. " " .. math.floor(object.storages[1].fillLevels[fillType_in_found2])  .. " fillType_in3 " .. filltypename_in3 .. " " .. math.floor(object.storages[1].fillLevels[fillType_in_found3]) .. "  fillType_out " .. filltypename_out .. " " .. math.floor(object.storages[1].fillLevels[fillType_out_found]));				
						end;
					end;
				end;
			end;
		end;
	end;
end; 

function FillTypeMover:draw()

end
